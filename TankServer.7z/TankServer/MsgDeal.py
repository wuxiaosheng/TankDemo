import os
import shutil
import json

class MsgDeal:
	def __init__(self, server):
		self.server = server
	def onDelegateDeal(self, data, player):
		if (getattr(self, data["msgType"])):
			getattr(self, data["msgType"])(json.loads(data["msgVal"].decode("utf8")), player)
	def CSMsgReady(self, data, player):
		player.notify("SCMsgReady", json.dumps({"code":1,"playerId":player.getPlayerId()}))
		hallRooms = self.server.roomMgr.getRoomByName("Hall")
		gameRoom = self.server.roomMgr.getFreeGameRoom()
		if (gameRoom):
			self.server.roomMgr.joinRoom(gameRoom.getRoomId(), player)
		else:
			gameRoom = self.server.roomMgr.createRoom("GameRoom")
			self.server.roomMgr.joinRoom(gameRoom.getRoomId(), player)
	def CSMsgGameStart(self, data, player):
		room = self.server.roomMgr.getRoomById(player.getCurRoomId())
		if (room != None):
			room.startFrame()
			room.notify("SCMsgGameStart", json.dumps({"frame":room.frame}))
	def CSMsgNetFrame(self, data, player):
		roomId = player.getCurRoomId()
		room = self.server.roomMgr.getRoomById(roomId)
		if (room):
			room.pushCmd(data["cmd"])
	def CSMsgGameOver(self, data, player):
		room = self.server.roomMgr.getRoomById(player.getCurRoomId())
		if (room != None):
			room.startFrame()
			room.notify("SCMsgGameOver", json.dumps({"playerId":data["playerId"]}))
	def CSMsgTankDemage(self, data, player):
		room = self.server.roomMgr.getRoomById(player.getCurRoomId())
		if (room != None):
			room.startFrame()
			room.notify("SCMsgTankDemage", json.dumps({"playerId":data["playerId"], "demage":data["demage"]}))