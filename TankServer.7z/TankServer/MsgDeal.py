import os
import shutil
import json

class MsgDeal:
	def __init__(self, server):
		self.server = server
	def onDelegateDeal(self, data, player):
		if (getattr(self, data["msgType"])):
			getattr(self, data["msgType"])(json.loads(data["msgVal"].decode("utf8")), player)
	def CSMsgReady(self, data, player):
		player.notify("SCMsgReady", json.dumps({"code":1,"playerId":player.getPlayerId()}))
		hallRoom = self.server.roomMgr.getRoomByName("Hall")
		self.server.roomMgr.joinRoom(hallRoom.getRoomId(), player)
		waitRoom = self.server.roomMgr.createRoom("WaitRoom")
		self.server.roomMgr.joinRoom(waitRoom.getRoomId(), player)
	def CSMsgGameStart(self, data, player):
		room = self.server.roomMgr.getRoomById(player.getCurRoomId())
		if (room != None):
			room.startFrame()
			player.notify("SCMsgGameStart", json.dumps({"frame":room.frame}))
	def CSMsgNetFrame(self, data, player):
		roomId = player.getCurRoomId()
		room = self.server.roomMgr.getRoomById(roomId)
		if (room):
			room.pushCmd(data["cmd"])