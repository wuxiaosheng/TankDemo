import os
import shutil
import socket
import select
import json

class Player:
	def __init__(self, socket, addr, id, server):
		self.server = server
		self.roomId = -1
		self.playerId = id
		self.socket = socket
		self.addr = addr
		self.name = addr
	def getBriefIntro(self):
		return {"playerId":self.playerId, "name":self.name}
	def getSocket(self):
		return self.socket
	def getPlayerId(self):
		return self.playerId
	def getCurRoomId(self):
		return self.roomId
	def onRemove(self):
		print("onRemove")
		if self.roomId != -1:
			room = self.server.roomMgr.getRoomById(self.roomId)
			room.onPlayerExit(self)
	def onPlayerJoin(self, roomId):
		self.roomId = roomId
	def onPlayerExit(self):
		self.roomId = -1
	def notify(self, msgType, msgVal):
		result = {}
		result["msgType"] = msgType
		result["msgVal"] = msgVal
		self.server.notify(self.playerId, json.dumps(result))

class PlayerMgr:
	def __init__(self, server):
		self.server = server
		self.count = 10000
		self.sockReflectId = {}
		self.players = {}
	def createPlayer(self, socket, addr):
		playerId = self.count
		self.players[playerId] = Player(socket, addr, playerId, self.server)
		self.count = self.count+1
		self.sockReflectId[socket] = playerId
		return self.players[playerId]
	def removePlayer(self, playerId):
		if (self.players[playerId] == None):
			return
		self.players[playerId].onRemove()
		print("remove player id:"+str(playerId))
		del self.players[playerId]
	def getPlayerBySocket(self, socket):
		if (self.sockReflectId[socket] != None):
			return self.getPlayerById(self.sockReflectId[socket])
		return None
	def getPlayerById(self, playerId):
		return self.players[playerId]
		