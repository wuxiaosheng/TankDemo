import os
import shutil
import socket
import select
import json
import PlayerManager
import MsgDeal
import RoomManager
import time
import threading

class GameServer:
	def __init__(self):
		self.timer = threading.Timer(1.0/10.0, self.update)
		self.timer.start()
		self.playerMgr = PlayerManager.PlayerMgr(self)
		self.msgDeal = MsgDeal.MsgDeal(self)
		self.roomMgr = RoomManager.RoomManager(self)
		self.roomMgr.createRoom("Hall")
		self.sockArr = []
		self.listenSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		self.listenSocket.bind(("192.168.1.10",19904))
		self.listenSocket.listen(5)
		self.sockArr.append(self.listenSocket)
		self.loop()
		
	def loop(self):
		while True:
			r, w, e = select.select(self.sockArr, [], [], 1)
			for sock in r:
				if (sock == self.listenSocket):
					self.onEvtNewClient(sock)
				else:
					self.onEvtRecvMsg(sock)
	def closeSocket(self, sock):
		for i in range(0, len(self.sockArr)):
			if (self.sockArr[i] == sock):
				del self.sockArr[i]
				break
		sock.close()
	def sendMsg(self, playerId, msgType, msgVal):
		player = self.playerMgr.getPlayerById(playerId)
		if (player == None):
			return
		result = {}
		result["msgType"] = msgType
		result["msgVal"] = msgVal
		self.sendMsg(player.getSocket(), json.dumps(result))
	def send(self, sock, msg):
		msg = msg+";"
		print("send msg:"+msg)
		try:
			sock.sendall(bytes(msg))
		except socket.error, e:
			print("socket send error")
			player = self.playerMgr.getPlayerBySocket(sock)
			self.onEvtSocketClose(player)
			print("player socket close")
			
	def notify(self, playerId, msg):
		player = self.playerMgr.getPlayerById(playerId)
		if (player == None):
			return
		self.send(player.getSocket(), msg)
	def onEvtNewClient(self, sock):
		conn, addr = sock.accept()
		self.sockArr.append(conn)
		player = self.playerMgr.createPlayer(conn, addr[0])
	def onEvtRecvMsg(self, sock):
		player = self.playerMgr.getPlayerBySocket(sock)
		if (player == None):
			return
		try:
			data = sock.recv(1024)
			if (len(data) == 1024):
				lessData = ""
				while True:
					temp = sock.recv(1024)
					lessData = lessData+temp
					if (len(temp) < 1024):
						break
				data = data+lessData
		except socket.error, e:
			print("socket error")
			data = ""
		if (data == ""):
			self.onEvtSocketClose(player)
			return
		datas = data.split(";")
		for res in datas:
			if (res == ""):
				continue
			#print(res)
			res = json.loads(res)
			self.msgDeal.onDelegateDeal(res, player)
	def onEvtSocketClose(self, player):
		print("player id:"+str(player.getPlayerId()))
		sock = player.getSocket()
		self.closeSocket(sock)
		self.playerMgr.removePlayer(player.getPlayerId())
	def update(self):
		#self.playerMgr.update()
		self.roomMgr.update()
		self.timer = threading.Timer(1.0/10.0, self.update)
		self.timer.start()
			
if __name__ == "__main__":
	server = GameServer()