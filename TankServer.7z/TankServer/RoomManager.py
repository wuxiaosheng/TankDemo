import os
import shutil
import json

class Room:
	def __init__(self, id, name):
		self.cmd = []
		self.playerList = []
		self.roomId = id
		self.name = name
		self.ownerId = 0
		self.frame = 0
		self.isRunFrame = False
	def isFull(self):
		return len(self.playerList) >= 8
	def getRoomId(self):
		return self.roomId
	def getRoomName(self):
		return self.name
	def getAllBriefIntro(self):
		data = []
		for player in self.playerList:
			data.append(player.getBriefIntro())
		return data
	def startFrame(self):
		self.isRunFrame = True
	def pushCmd(self, cmd):
		self.cmd.append(cmd)
	def isNull(self):
		return len(self.playerList) == 0
	def onRemove(self):
		self.playerList.clear()
	def onPlayerJoin(self, player):
		player.onPlayerJoin(self.roomId)
		self.playerList.append(player)
		self.ownerId = self.playerList[0].getPlayerId()
		allBriefIntro = self.getAllBriefIntro()
		self.notify("SCMsgJoinRoom", json.dumps({"players":allBriefIntro, "ownerId":self.ownerId}))
	def onPlayerExit(self, player):
		player.onPlayerExit()
		for i in range(0, len(self.playerList)):
			if (self.playerList[i] == player):
				del self.playerList[i]
				break
		self.notify("SCMsgExitRoom", json.dumps({"player":player.getBriefIntro()}))
	def notify(self, msgType, msgVal):
		for player in self.playerList:
			#print("room notify player id:"+str(player.getPlayerId()))
			player.notify(msgType, msgVal)
	def update(self):
		self.frame = self.frame+1
		self.notify("SCMsgNetFrame", json.dumps({"frame":self.frame, "cmd":self.cmd}))
		self.cmd = []

class RoomManager:
	def __init__(self, server):
		self.count = 1000101
		self.server = server
		self.nameIdReflect = {}
		self.rooms = {}
	def createRoom(self, name):
		roomId = self.count
		self.rooms[roomId] = Room(self.count, name)
		self.count = self.count+1
		self.nameIdReflect[name] = roomId
		return self.rooms[roomId]
	def removeRoom(self, roomId):
		print("remove room id:"+str(roomId))
		if (self.rooms[roomId] == None):
			return
		self.rooms[roomId].onRemove()
		del self.rooms[roomId]
	def getRoomById(self, roomId):
		return self.rooms[roomId]
	def getRoomByName(self, name):
		rooms = []
		for key in self.rooms:
			if (self.rooms[key].getRoomName() == name):
				rooms.append(self.rooms[key])
		return rooms
	def getFreeGameRoom(self):
		waitRooms = self.getRoomByName("GameRoom")
		for room in waitRooms:
			if (not room.isFull()):
				return room
	def joinRoom(self, roomId, player):
		room = self.getRoomById(roomId)
		if (room == None):
			return
		roomId = player.getCurRoomId()
		if (roomId != -1):
			self.exitRoom(roomId, player)
		room.onPlayerJoin(player)
	def exitRoom(self, roomId, player):
		room = self.getRoomById(roomId)
		if (room == None):
			return
		room.onPlayerExit(player)
	def notify(self, roomId, msgType, msgVal):
		room = self.getRoomById(roomId)
		if (room == None):
			return
		room.notify(msg)
	def update(self):
		for key in self.rooms:
			if (self.rooms[key].isRunFrame):
				self.rooms[key].update()
				if (self.rooms[key].isNull()):
					del self.rooms[key]
					break
		
		